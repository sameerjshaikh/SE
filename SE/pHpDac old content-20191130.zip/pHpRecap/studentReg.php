<!DOCTYPE html>
<html>
<head>
	<title>Student Registration</title>
</head>
<body>
	<h1>Student Registration Form</h1>
	<div>
	<form action="studentReg_process.php" method="POST">
		<input type="text" name="name" placeholder="Enter Name"/>
		<input type="text" name="address" placeholder="Enter address"/>
		<input type="number" name="phone" placeholder="Enter phone no"/>
		<button>Register</button>
	</form>
	</div>
</body>
</html>